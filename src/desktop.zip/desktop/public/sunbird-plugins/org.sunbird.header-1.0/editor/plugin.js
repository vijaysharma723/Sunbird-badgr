org.ekstep.contenteditor.basePlugin.extend({
	initialize: function() {}
});