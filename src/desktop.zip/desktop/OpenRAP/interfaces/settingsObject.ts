export interface SettingsObject {
  id: string,  // Setting id
  value: object, // Setting value
}
