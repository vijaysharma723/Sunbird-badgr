
export interface DownloadFile {
    id: string,
    url: string,
    size: number
}