export const faqOfflineEn = {
  "faqs": [
    {
      "topic": "Offline content for en",
      "description": "test data"
    }
  ],
  "constants": {
    "testConst": "testConst offline"
  }
}
export const faqOnlineEn = {
  "faqs": [
    {
      "topic": "online content for en",
      "description": "test data"
    }
  ],
  "constants": {
    "testConst": "testConst online"
  }
}