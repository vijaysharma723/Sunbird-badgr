export const manifest = {
  "id": "openrap-sunbirded-plugin",
  "name": "sunbird-ed openrap plugin ",
  "author": "sunbird",
  "version": "1.0"
  }