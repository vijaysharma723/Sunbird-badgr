export interface ILocation {
    id: string;
    type: string;
    code: string;
    name: string;
    data: string[];
  }
